/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() //entry point funcion Principal
{
     /*
    Tipos de datos
    int (%d o %i) : -9; 8; 459 .... 4 Bytes 0000000000000000010
    float (%f) : 3.25; -9.47; 8; 4/5 .... 4 Bytes
    char (%c) : 'a'; '1'; '@' .... 1 Byte -128 - 127  o 0 - 255
    double (%lf): .... 8 Bytes
    void : ¿?
    */
    
    /*
    Secuencias de escape
    \n Salto de linea
    \t Tabulacion
    \a Alarma (beep)
    
    mostar datos
    printf("cadena de texto");
    
    scanf("mascara", &direccion);
    */
   
    int unNumero;
    float unNumeroFlotante;
    int x;
    unNumero = -9;
    unNumeroFlotante = 3.14;
    x = 10;

    
    printf("El numero entero es: %d\n EL numero Flotante es : %f\a\n El numero x es: %i", unNumero,unNumeroFlotante,x);
   
    return 0;
}




